# Core: Quest Mode

## Когда применять

- Для задач, где нужен обязательный `SPEC`-first цикл.
- Для изменений с повышенным риском, где нужно явно зафиксировать рамки перед реализацией.

## Когда не применять

- Для одношаговых справочных или формальных вопросов без изменения файлов.
- Когда результатом является только чтение/резюме уже существующей документации.

## MUST

- Перед любым изменением создавать/обновлять рабочую спецификацию в локальном `./specs/` репозитория задачи.
- Для шаблона использовать canonical путь `templates/specs/_template.md` из каталога инструкций, откуда загружены текущие правила.
- Не использовать локальный template из репозитория задачи как source template.
- Если canonical template не найден в центральном каталоге, останавливать фазу `SPEC` с явным сообщением о сломанном onboarding-контракте.
- Выбрать профиль из `instructions/profiles/*` и зафиксировать его в спецификации.
- Рабочая спецификация обязана содержать финальный раздел `Журнал действий агента` по canonical template.
- На фазе `SPEC` разрешено изменять только текущую рабочую спецификацию в локальном `./specs/`.
- До фразы пользователя `Спеку подтверждаю` запрещено менять код, инфраструктуру, `instructions/*`, `prompts/*`, `templates/*`, `scripts/*`, `README.md`, `CHANGELOG.md` и другие файлы проекта вне текущей рабочей спецификации.
- На фазе SPEC использовать `instructions/governance/spec-linter.md`, `instructions/governance/spec-rubric.md` и `instructions/governance/review-loops.md`.
- Перед запросом подтверждения спецификации выполнять full `post-SPEC review-loop` по `instructions/governance/review-loops.md`, вносить объективно лучшие правки в spec и повторять затронутые quality gate проверки.
- Перед запросом подтверждения спецификации выполнять `Pre-Approval Rework Prevention Gate`: заполнить или явно пометить как `Не применимо` с причиной `User-Observable Scenarios`, `Decision Ledger`, `Acceptance-to-Test Matrix`, `Expected User Review Objections` и `Role-Based Review Result`; если `Decision Ledger` содержит user-owned решение, блокирующее EXEC, задать точный вопрос вместо запроса approval.
- В `Pre-Approval Rework Prevention Gate` для small-задач допустимо компактное заполнение, но нельзя пропускать user-observable scenario, decision ledger, acceptance-to-test mapping или likely objection без проверяемой причины.
- Фразу пользователя `Спеку подтверждаю` считать единственным переходом из фазы `SPEC` в фазу `EXEC`.
- На фазах `SPEC` и `EXEC` после каждого значимого блока работ обновлять журнал действий агента в текущей рабочей спецификации, отдельно фиксируя ожидаемую передачу решения человеку и фактическое обращение к человеку / решение человека.
- На фазе EXEC реализовывать только в границах `Non-Goals` и ограничений спецификации.
- Перед финальным отчётом выполнять `User-Observable Completion Gate`: сверить реализацию с `User-Observable Scenarios`, проверки с `Acceptance-to-Test Matrix`, а `Expected User Review Objections` закрыть или явно оставить как approved residual risk / follow-up из утверждённой spec.
- Перед финальным отчётом выполнять full `post-EXEC review-loop` по `instructions/governance/review-loops.md`, исправлять все findings с однозначным исправлением, повторять затронутые проверки и только потом завершать задачу.
- Если review упирается в несколько жизнеспособных вариантов без единственного оптимального решения, запрашивать решение у пользователя.

## SHOULD

- Перед утверждением спецификации убедиться, что нет блокирующих `Открытых вопросов`.
- Включать `Acceptance Criteria` и список проверочных команд в конце спеки.
- Хранить отчёт в формате, удобном для последующего аудита (`Summary`, `Changed files`, `Tests`, `Review`, `Commands`, `How to verify`, `Follow-ups`).

## MAY

- Добавлять отдельные доменные профили из `instructions/profiles/*` (например, для миграции архитектуры, UI parity и т.п.).
- Использовать шаблоны prompt для ускорения старта этапов.

## Команды

```powershell
Get-Content <AGENTS_ROOT>\templates\specs\_template.md
Get-Content .\instructions\governance\spec-linter.md
Get-Content .\instructions\governance\spec-rubric.md
Get-Content .\instructions\governance\review-loops.md
```

## Связанные документы

- [instructions/core/quest-governance.md](./quest-governance.md)
- [instructions/core/quest-prompt-spec.md](./quest-prompt-spec.md)
- [instructions/core/quest-prompt-exec.md](./quest-prompt-exec.md)
- [templates/specs/_template.md](../../templates/specs/_template.md)
- [instructions/governance/spec-linter.md](../governance/spec-linter.md)
- [instructions/governance/spec-rubric.md](../governance/spec-rubric.md)
- [instructions/governance/review-loops.md](../governance/review-loops.md)
